package com.example.dragovicd.popis;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dragovicd.popis.entity.Artikal;

import java.util.List;

import static android.widget.Toast.*;

/**
 * Created by Belal on 9/30/2017.
 */

public class ArtikliAdapter extends ArrayAdapter<Artikal> {

    Context mCtx;
    int listLayoutRes;
    List<Artikal> artikliList;
    DatabaseHelper db;


    public ArtikliAdapter(Context mCtx, int listLayoutRes, List<Artikal> artikliList) {
        super(mCtx, listLayoutRes, artikliList);

        this.mCtx = mCtx;
        this.listLayoutRes = listLayoutRes;
        this.artikliList = artikliList;
        db = new DatabaseHelper(mCtx);
    }

    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //final int position_n = position;

        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(listLayoutRes, null);

        Artikal artikal = artikliList.get(position);
        TextView textViewSifra = view.findViewById(R.id.sifra);
        TextView textViewNaziv = view.findViewById(R.id.naziv);
        TextView textViewLokacija = view.findViewById(R.id.lokacija);
        textViewSifra.setText(artikal.getSifra());
        textViewNaziv.setText(artikal.getNaziv());
        textViewLokacija.setText(artikal.getLokacija());


        final String artikal_sifra = artikal.getSifra();
        final String popisan = artikal.getPopisan();
        //final int y = Integer.valueOf(popisan);
        if (artikal.getPopisan() != null){
            if (Integer.parseInt(artikal.getPopisan()) == 1) {
                view.setBackgroundColor(Color.GREEN);
            }
        }
        view.setOnLongClickListener(new View.OnLongClickListener() {

            @Override
            public boolean onLongClick(final View view) {
                CharSequence colors[] = new CharSequence[]{"Uredi", "Obriši"};

                AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
                builder.setTitle("Artikal šifra: "+ artikal_sifra);
                builder.setItems(colors, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            goToArtikliUredjivanje(view, artikal_sifra);
                        } else {
                            db.deleteArtikal(artikal_sifra);
                            goToArtikliAllList(view);
                        }
                    }
                });
                builder.show();

                return false;
            }
        });





        return view;
    }

    public void goToArtikliAllList(View v) {
        Intent intent = new Intent(mCtx, ArtikliActivity.class);

        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        mCtx.startActivity(intent);

    }

    public void goToArtikliUredjivanje(View v, String artikal_sifra) {
        Intent intent = new Intent(mCtx, ArtikliUredjivanje.class);
        intent.putExtra("STRING_I_NEED", artikal_sifra);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        mCtx.startActivity(intent);
    }


}
