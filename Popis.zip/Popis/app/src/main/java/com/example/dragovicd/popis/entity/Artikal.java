package com.example.dragovicd.popis.entity;

public class Artikal {

    //Table name
    public static final String TABLE_NAME = "artikli";

    //Create table Query
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_SIFRA= "sifra";
    public static final String COLUMN_NAZIV= "naziv";
    public static final String COLUMN_LOKACIJA= "lokacija";
    public static final String COLUMN_SLIKA= "slika";
    public static final String COLUMN_POPISAN= "popisan";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    // Create table SQL query
    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_SIFRA + " TEXT,"
                    + COLUMN_NAZIV + " TEXT,"
                    + COLUMN_LOKACIJA + " TEXT,"
                    + COLUMN_SLIKA + " TEXT,"
                    + COLUMN_POPISAN + " TEXT,"
                    + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                    + ")";


    private String  sifra, naziv, lokacija, slika, popisan, timestamp;

    private int id;


    public Artikal() {
    }

    public Artikal(int id, String sifra, String naziv,String lokacija, String slika, String popisan, String timestamp) {
        this.id = id;
        this.sifra =sifra;
        this.naziv =naziv;
        this.lokacija =lokacija;
        this.slika =slika;
        this.popisan =popisan;
        this.timestamp = timestamp;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getLokacija() {
        return lokacija;
    }

    public void setLokacija(String lokacija) {
        this.lokacija = lokacija;
    }

    public String getSlika() {
        return slika;
    }

    public void setSlika(String slika) {
        this.slika = slika;
    }

    public String getPopisan() {
        return popisan;
    }

    public void setPopisan(String popisan) {
        this.popisan = popisan;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
