package com.example.dragovicd.popis;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.dragovicd.popis.entity.Artikal;

public class ArtikliUredjivanje extends AppCompatActivity {
DatabaseHelper db;

    EditText sifraArtikla;
    EditText nazivArtikla;
    EditText lokacijaArtikla;
    Bundle bundle;
    String newString;
    Artikal artikal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.artikal_uredjivanje);
        db = new DatabaseHelper(this);
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Artikal uređivanje");
        toolbar.setTitleTextColor(Color.parseColor("#FFFFFF"));
        nazivArtikla = (EditText) findViewById(R.id.eteNazivArtikla);
        lokacijaArtikla = (EditText) findViewById(R.id.eteLokacijaArtikla);



        if (savedInstanceState == null) {
            Bundle extras = getIntent().getExtras();
            if(extras == null) {
                newString= null;
            } else {
                newString= extras.getString("STRING_I_NEED");
                artikal = db.getArtikalBySifra(newString);
                nazivArtikla.setText(artikal.getNaziv());
                lokacijaArtikla.setText(artikal.getLokacija());
            }
        } else {
            newString= (String) savedInstanceState.getSerializable("STRING_I_NEED");
        }


        //Toast.makeText(this, newString, Toast.LENGTH_SHORT).show();
    }

    public void goToArtikliLista(View v) {

        Intent intent = new Intent(ArtikliUredjivanje.this,  ArtikliActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);

    }

    public void updateArtikal(View v) {

        artikal.setNaziv((nazivArtikla.getText()).toString());
        artikal.setLokacija((lokacijaArtikla.getText()).toString());
        db.updateArtikal(artikal);
        goToArtikliLista(v);
    }
}