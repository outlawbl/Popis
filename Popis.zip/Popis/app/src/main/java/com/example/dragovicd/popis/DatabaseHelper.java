package com.example.dragovicd.popis;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.dragovicd.popis.entity.Artikal;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "popis_db";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // create notes table
        db.execSQL(Artikal.CREATE_TABLE);
    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + Artikal.TABLE_NAME);

        // Create tables again
        onCreate(db);
    }


    public void onDropTableArtikli() {
        // Drop older table if existed
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + Artikal.TABLE_NAME);

        // Create tables again
        onCreate(db);
    }
    public void insertArtikalR(String sifraArtikla, String nazivArtikla, String lokacijaArtikla) {

    }
    public long insertArtikalR2(Artikal artikal) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put(Artikal.COLUMN_SIFRA, artikal.getSifra());
        values.put(Artikal.COLUMN_NAZIV, artikal.getNaziv());
        values.put(Artikal.COLUMN_LOKACIJA, artikal.getLokacija());
        values.put(Artikal.COLUMN_SLIKA, artikal.getSlika());
        values.put(Artikal.COLUMN_POPISAN, artikal.getPopisan());
        // insert row
        long id = db.insert(Artikal.TABLE_NAME, null, values);

        // close db connection
        db.close();

        // return newly inserted row id
        return id;
    }

    public long insertArtikal(Artikal artikal) {
        // get writable database as we want to write data
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        // `id` and `timestamp` will be inserted automatically.
        // no need to add them
        values.put(Artikal.COLUMN_SIFRA, artikal.getSifra());
        values.put(Artikal.COLUMN_NAZIV, artikal.getNaziv());
        values.put(Artikal.COLUMN_LOKACIJA, artikal.getLokacija());
        values.put(Artikal.COLUMN_SLIKA, artikal.getSlika());
        values.put(Artikal.COLUMN_POPISAN, artikal.getPopisan());
        // insert row
        long id = db.insert(Artikal.TABLE_NAME, null, values);

        // close db connection
        db.close();

        // return newly inserted row id
        return id;
    }

    public Artikal getArtikal(long id) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Artikal.TABLE_NAME,
                new String[]{
                        Artikal.COLUMN_ID,
                        Artikal.COLUMN_SIFRA,
                        Artikal.COLUMN_NAZIV,
                        Artikal.COLUMN_LOKACIJA,
                        Artikal.COLUMN_SLIKA,
                        Artikal.COLUMN_POPISAN,
                        Artikal.COLUMN_TIMESTAMP
                },
                Artikal.COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare artikal object

        Artikal artikal = new Artikal(
                cursor.getInt(cursor.getColumnIndex(Artikal.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SIFRA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_NAZIV)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_LOKACIJA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SLIKA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_POPISAN)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_TIMESTAMP)));




        // close the db connection
        cursor.close();

        return artikal;
    }

    public Artikal getArtikalBySifra(String sifra) {
        // get readable database as we are not inserting anything
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(Artikal.TABLE_NAME,
                new String[]{
                        Artikal.COLUMN_ID,
                        Artikal.COLUMN_SIFRA,
                        Artikal.COLUMN_NAZIV,
                        Artikal.COLUMN_LOKACIJA,
                        Artikal.COLUMN_SLIKA,
                        Artikal.COLUMN_POPISAN,
                        Artikal.COLUMN_TIMESTAMP
                },
                Artikal.COLUMN_SIFRA + "=?",
                new String[]{String.valueOf(sifra)}, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        // prepare artikal object

        Artikal artikal = new Artikal(
                cursor.getInt(cursor.getColumnIndex(Artikal.COLUMN_ID)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SIFRA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_NAZIV)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_LOKACIJA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SLIKA)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_POPISAN)),
                cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_TIMESTAMP)));




        // close the db connection
        cursor.close();

        return artikal;
    }


    public List<Artikal> getAllArtikal() {
        List<Artikal> artikli = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + Artikal.TABLE_NAME + " ORDER BY " +
                Artikal.COLUMN_TIMESTAMP + " DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Artikal artikal = new Artikal();
                artikal.setId(cursor.getInt(cursor.getColumnIndex(Artikal.COLUMN_ID)));
                artikal.setSifra(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SIFRA)));
                artikal.setNaziv(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_NAZIV)));
                artikal.setLokacija(cursor.getString(cursor.getColumnIndex(artikal.COLUMN_LOKACIJA)));
                artikal.setSlika(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SLIKA)));
                artikal.setPopisan(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_POPISAN)));
                artikal.setTimestamp(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_TIMESTAMP)));
             artikli.add(artikal);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return notes list
        return artikli;
    }



    public int updateArtikal(Artikal artikal) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Artikal.COLUMN_NAZIV, artikal.getNaziv());
        values.put(Artikal.COLUMN_LOKACIJA, artikal.getLokacija());
        //values.put(Artikal.COLUMN_SLIKA, artikal.getSlika());
        //values.put(Artikal.COLUMN_POPISAN, artikal.getPopisan());

        // updating row
        int id = db.update(Artikal.TABLE_NAME, values, Artikal.COLUMN_SIFRA + " = ?",
                new String[]{String.valueOf(artikal.getSifra())});
        db.close();
        return id;
    }



    public int popisArtikal(String art_sifra) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Artikal.COLUMN_POPISAN, "1");

        // updating row
        int id = db.update(Artikal.TABLE_NAME, values, Artikal.COLUMN_SIFRA + " = ?",
                new String[]{String.valueOf(art_sifra)});

        db.close();
        return id;
    }

    public void deleteArtikal(String art_sifra) {
        //Toast.makeText(context, "Ovo je artikal " + art_sifra, Toast.LENGTH_SHORT).show();

        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Artikal.TABLE_NAME, Artikal.COLUMN_SIFRA + " = ?",
               new String[]{String.valueOf(art_sifra)});
        db.close();
    }


    public List<Artikal> exportDataToCsv() {
        List<Artikal> artikli = new ArrayList<>();

        // Select All Query
        String arg="1";
        String selectQuery = "SELECT  * FROM " + Artikal.TABLE_NAME + " WHERE "+ Artikal.COLUMN_POPISAN + "="+arg+" ORDER BY " +
                Artikal.COLUMN_TIMESTAMP + " DESC";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Artikal artikal = new Artikal();
                artikal.setId(cursor.getInt(cursor.getColumnIndex(Artikal.COLUMN_ID)));
                artikal.setSifra(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SIFRA)));
                artikal.setNaziv(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_NAZIV)));
                artikal.setLokacija(cursor.getString(cursor.getColumnIndex(artikal.COLUMN_LOKACIJA)));
                artikal.setSlika(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_SLIKA)));
                artikal.setPopisan(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_POPISAN)));
                artikal.setTimestamp(cursor.getString(cursor.getColumnIndex(Artikal.COLUMN_TIMESTAMP)));
                artikli.add(artikal);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();

        // return notes list
        return artikli;
    }

}
